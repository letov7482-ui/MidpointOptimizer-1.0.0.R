package com.midpoint.optimization;

import com.midpoint.config.MidpointConfig;

public class SmartSafeOptimizations {
    public static boolean shouldOptimize() {
        return MidpointConfig.smartSafeOptimizations;
    }

    public static int getOptimizedRenderDistance(int current) {
        if (!shouldOptimize()) return current;
        // Logic to dynamically adjust render distance based on system load
        return Math.max(2, current - (MidpointConfig.lowEndPreset ? 4 : 0));
    }
}
