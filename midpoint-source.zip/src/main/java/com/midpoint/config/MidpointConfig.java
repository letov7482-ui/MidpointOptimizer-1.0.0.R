package com.midpoint.config;

import java.io.*;
import java.util.Properties;

public class MidpointConfig {
    public static boolean lowEndPreset = false;
    public static boolean adaptiveFpsHud = true;
    public static boolean smartSafeOptimizations = true;
    public static String optimizerFunction = "x^2 + y^2";

    private static final File CONFIG_FILE = new File("config/midpoint.properties");

    public static void load() {
        if (!CONFIG_FILE.exists()) {
            save();
            return;
        }
        try (InputStream input = new FileInputStream(CONFIG_FILE)) {
            Properties prop = new Properties();
            prop.load(input);
            lowEndPreset = Boolean.parseBoolean(prop.getProperty("lowEndPreset", "false"));
            adaptiveFpsHud = Boolean.parseBoolean(prop.getProperty("adaptiveFpsHud", "true"));
            smartSafeOptimizations = Boolean.parseBoolean(prop.getProperty("smartSafeOptimizations", "true"));
            optimizerFunction = prop.getProperty("optimizerFunction", "x^2 + y^2");
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void save() {
        try (OutputStream output = new FileOutputStream(CONFIG_FILE)) {
            Properties prop = new Properties();
            prop.setProperty("lowEndPreset", String.valueOf(lowEndPreset));
            prop.setProperty("adaptiveFpsHud", String.valueOf(adaptiveFpsHud));
            prop.setProperty("smartSafeOptimizations", String.valueOf(smartSafeOptimizations));
            prop.setProperty("optimizerFunction", optimizerFunction);
            prop.store(output, null);
        } catch (IOException io) {
            io.printStackTrace();
        }
    }
}
