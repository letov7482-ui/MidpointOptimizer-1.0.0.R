package com.midpoint.config.screen;

import com.midpoint.config.MidpointConfig;
import com.midpoint.midpointoptimizer.MidpointOptimizer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class MidpointConfigScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget functionField;
    private String resultText = "";

    public MidpointConfigScreen(Screen parent) {
        super(Text.literal("Midpoint Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int y = 40;

        // Low End Preset Toggle
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Low End Preset: " + (MidpointConfig.lowEndPreset ? "ON" : "OFF")), button -> {
            MidpointConfig.lowEndPreset = !MidpointConfig.lowEndPreset;
            button.setMessage(Text.literal("Low End Preset: " + (MidpointConfig.lowEndPreset ? "ON" : "OFF")));
        }).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 30;

        // Optimizer Function Field
        this.functionField = new TextFieldWidget(this.textRenderer, this.width / 2 - 100, y, 200, 20, Text.literal("Function"));
        this.functionField.setText(MidpointConfig.optimizerFunction);
        this.addSelectableChild(this.functionField);

        y += 25;

        // Optimize Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Optimize"), button -> {
            MidpointConfig.optimizerFunction = this.functionField.getText();
            this.resultText = MidpointOptimizer.optimize(MidpointConfig.optimizerFunction);
        }).dimensions(this.width / 2 - 100, y, 200, 20).build());

        y += 40;

        // Done Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> {
            MidpointConfig.save();
            this.client.setScreen(this.parent);
        }).dimensions(this.width / 2 - 100, this.height - 40, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 15, 0xFFFFFF);
        this.functionField.render(context, mouseX, mouseY, delta);
        
        if (!resultText.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal(resultText), this.width / 2, 120, 0x00FF00);
        }
        
        super.render(context, mouseX, mouseY, delta);
    }
}
