package com.midpoint;

import com.midpoint.config.MidpointConfig;
import com.midpoint.config.screen.MidpointConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MidpointMod implements ClientModInitializer {
    public static final String MOD_ID = "midpoint";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyBinding openConfigKey;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing Midpoint Mod for Fabric 1.21.11");
        MidpointConfig.load();

        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.midpoint.open_config",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                "category.midpoint.general"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openConfigKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new MidpointConfigScreen(null));
                }
            }
        });
    }

    public static MinecraftClient client() {
        return MinecraftClient.getInstance();
    }
}
